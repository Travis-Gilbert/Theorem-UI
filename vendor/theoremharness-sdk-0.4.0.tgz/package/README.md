# Theorem TypeScript SDK

Fern-generated native contracts for participating in Theorem's environment.
Chat is one supported slice, with an optional assistant-ui adapter. Runtime code uses native fetch and has no React dependency.
The package builds ESM, CommonJS, and TypeScript declarations for Node 20+ and
modern browsers. It has not been published to npm.

## Build and install locally

```sh
cd packages/theorem-sdk
npm ci
npm run build
npm pack
```

Install the resulting tarball into your frontend. Import from
`@theoremharness/sdk`; the optional adapter is `@theoremharness/sdk/assistant-ui`.
The adapter is checked against `@assistant-ui/react@0.15.30` (optional peer).

## Native environment operations

The root client has independent `records`, `documents`, `spaces`, `workbench`,
`projectFiles`, `capabilities`, `extensions`, `remoteWorkspaces`, `documentSessions`
and `ide` resources. A record edit is a native form patch; a document
write is a revisioned document commit; a Space change saves presentation state.
None requires a chat message, tool-result card, or assistant-ui runtime.

```ts
const form = await client.records.get({ recordId: 'record-1' });
const result = await client.records.patch({
  recordIdPath: form.record_id,
  record_id: form.record_id,
  form_id: form.form_id,
  expected_revision: form.accepted_revision,
  request_id: operationKey,
  operations: [{ kind: 'set_value', field_id: titleFieldId,
    value: { kind: 'text', value: 'Edited directly' } }],
  'X-CSRF-Token': csrfToken,
  'Idempotency-Key': operationKey,
});
// A protocol conflict/refusal may be HTTP 200: inspect the native receipt.
if (result.receipt.outcome.kind === 'conflict') {
  console.log(result.receipt.outcome.actual_revision);
}
```

`examples/environment.ts` includes typed record edits, canonical document commits,
and independent Space presentation saves. Path/body identities use distinct SDK
names (`recordIdPath`, `documentIdPath`, `workspaceIdPath`) where the native wire
requires both copies. The generated client preserves both instead of dropping a
body field while constructing a URL.

Each owner keeps its revision and refusal vocabulary. Record revisions are
strings carried by `expected_revision`; document revisions include a position
and digest; Space and workbench writes use their own revision and `If-Match`.
Document errors are typed under `Theorem.documents`, record transport errors
under `Theorem.records`, and record protocol outcomes stay in their receipts.

Use `client.environment.bootstrap()` for authenticated environment identity and
shared CSRF protection. It creates no chat state. The original
`session.bootstrap()` remains available for chat integrations. Resource methods
do not bootstrap implicitly.

## Client

```ts
import { TheoremClient, Theorem } from '@theoremharness/sdk';

// Server-side: use an existing Theorem credential with tenant:read/tenant:write
// and models:invoke when starting turns. Tenant is derived by the server.
const client = new TheoremClient({
  baseUrl: process.env.THEOREM_API_URL!,
  token: () => process.env.THEOREM_API_TOKEN!,
});

const session = await client.session.bootstrap();
const project = await client.chat.projects.create({
  title: 'Research',
  'X-CSRF-Token': session.csrfToken,
  'Idempotency-Key': crypto.randomUUID(),
});
const thread = await client.chat.threads.create({
  projectId: project.record.projectId,
  'X-CSRF-Token': session.csrfToken,
  'Idempotency-Key': crypto.randomUUID(),
});
const turn = await client.chat.messages.send({
  threadId: thread.record.threadId,
  branchId: thread.record.selectedBranchId,
  text: 'Hello, Theorem',
  'X-CSRF-Token': session.csrfToken,
  'Idempotency-Key': crypto.randomUUID(),
  'If-Match': String(thread.record.revision),
});
for await (const event of await client.chat.runs.events({ runId: turn.run.runId, after_seq: 0 })) {
  console.log(event.sourceEventType, event.payload);
}
```

In a browser with an existing Theorem session, use
`new TheoremClient({ baseUrl: window.location.origin, auth: false })`. Requests
include cookies. Use a same-origin reverse proxy for a separately hosted frontend;
this SDK does not establish login or configure backend CORS. Never embed a server
API token in frontend code. `baseUrl` may include an owner/path prefix.

Mutation headers are explicit. Keep an operation's idempotency key and original
request unchanged for a retry. Implicit retries default to zero: terminals, SCM,
workers and extension actions retain their native effect and retry semantics.
Override `maxRetries` only for an operation whose owner permits repetition. Revisioned mutations require `If-Match`; refresh the thread before
a new operation. Typed problems include `code`, `correlationId`, `receiptId`, and
`currentRevision` where the server provides them. For example:

```ts
try { /* a revisioned mutation */ }
catch (error) {
  if (error instanceof Theorem.ConflictError) console.log(error.body.code);
  else throw error;
}
```

## assistant-ui

```tsx
import { useMemo } from 'react';
import { AssistantRuntimeProvider, useLocalRuntime } from '@assistant-ui/react';
import { createTheoremChatAdapter, toAssistantMessages } from '@theoremharness/sdk/assistant-ui';

// Load before mounting: snapshot = await client.chat.threads.get({ threadId }).
function Chat({ client, threadId, snapshot, children }) {
  const adapter = useMemo(() => createTheoremChatAdapter({ client, threadId }), [client, threadId]);
  const runtime = useLocalRuntime(adapter, { initialMessages: toAssistantMessages(snapshot.messages, snapshot.thread) });
  return <AssistantRuntimeProvider runtime={runtime}>{children}</AssistantRuntimeProvider>;
}
```

A fully typed provider/loader example is in `examples/assistant-ui.tsx`. Mount your
assistant-ui Thread inside the provider and use `key={threadId}` when switching
threads. The adapter sends the latest user turn; Theorem owns the full history.
Regeneration of known durable user IDs calls retry; edits retaining those IDs
call edit. Custom editing UIs that replace user IDs should invoke
`client.chat.messages.edit` and reload the returned branch. Initial history preserves
server IDs for regeneration after reload.

Cumulative text/reasoning parts replace their earlier version. Tool calls/results
merge by toolCallId; native parts use assistant-ui data parts named
`theorem-<type>`. `onEvent` exposes all native events. Tools execute on the server;
do not register client executors for the same tools. Approval requests remain
native events/data; send decisions through `client.chat.runs.command` and provide
appropriate UI. The adapter does not install an approval UI or attachment uploader.
For already uploaded files, use `client.chat.messages.send({ ..., uploadIds })`.

Stop aborts the stream and records a separate durable run cancellation. A stop
pressed during submission waits for its run handle, then cancels it. Server
cancellation is cooperative. Cancellation failures propagate. Failed runs,
interrupted outcomes, and streams ending without a terminal event are not marked
successful. Existing active/pending turns require explicit recovery before a new
adapter run.

## Streaming and recovery

`client.chat.runs.events` returns a Fern AsyncIterable. `stream.withMetadata()` adds
SSE IDs. Resume with `after_seq: lastEvent.seq` or `'Last-Event-ID': savedId`
(the header takes precedence). The server emits no special SSE terminator, so
this SDK deliberately does not enable Fern's terminator-dependent automatic
reconnection. If a connection drops, resume the same run; do not send the user
message again. The assistant-ui adapter surfaces interrupted streams so the host
can present recovery. When reading from sequence zero, replace parts by partId.

## Supported contracts

| Resource | Methods |
| --- | --- |
| environment | bootstrap (product identity and shared CSRF) |
| capabilities | list and describe canonical descriptors, policy, maturity and proof |
| remoteWorkspaces | list, open, describe, close, restart, attach, detach, listWorkers, startWorker, crashWorker, bindCheckout, attachDebug |
| documentSessions | native source-document open, edit, transaction, undoTransaction, head, history, reconciliation and replication |
| extensions | native IDE extension discover/install/enable/disable/update/pin/activate/restartHost |
| extensions.apps | app manifests, extension points/contributions, drafts, install/update/uninstall, consent/deny/refresh |
| ide | operation discovery and native workspace, workbench, language, navigation, diagnostics, refactor, terminal, SCM, run, test, debug, history and custom-editor services |
| session | original chat bootstrap |
| records | list, get, surface, create, patch, history |
| documents | list, get, snapshot, create, revise, transact, promote, changes |
| spaces | identity, list, get, save |
| workbench | get, save (presentation state) |
| projectFiles | root, children, content (bound checkout reads) |
| chat.projects | list, create, update |
| chat.threads | list, create, get, update, delete, restore, fork |
| chat.messages | send, edit, retry |
| chat.runs | events, cancel, command |
| acp | agents, list, start, close |

The contract is `fern/openapi.json`, titled **Theorem Environment API**, with 255
operations. Every operation names its native source owner in `x-theorem-source`.
`generated/` is actual Fern output; `generated/reference.md` lists signatures.
The first chat package's root project/thread/message/run getters and request type
aliases remain for compatibility; use `client.chat` for new integrations.

The 184 IDE service operations are derived from the owner's actual advertised
registry by `scripts/update-environment-contract.mjs`. Formal native records
have typed request/response models. Services whose native contract is
`serde_json::Value` retain JSON arguments and return their exact JSON value;
the SDK does not invent a replacement protocol. Native subscription operations
retain the host's current acknowledgement/polling semantics. Chat has its own
SSE stream.

Remote execution uses the existing `theorem-ide-host` supervisor with an
fsynced RedCore source-document authority. The product server authenticates the
user, derives tenant/actor, checks an explicit principal execution grant, then
forwards to that tenant's configured native host. Missing host configuration
fails closed. See [host configuration](../../apps/theorem-ide-host/README.md).
The SDK opens workspaces on a configured host; deployment infrastructure
provisions that host. Host credentials never belong in frontend code.

`client.documentSessions.transaction()` commits native multi-file source edits
atomically; `preview: true` returns the native preview. By contrast,
`client.documents.transact()` imports a batch of base64 Loro wire updates into a
staged written-document session, then commits one revision through the document
product authority. It validates the native position/digest precondition and
idempotency key. Invalid or dependency-incomplete batches publish nothing.
Use the Loro library to create updates; the SDK contains no CRDT encoder.

Capability discovery verifies and returns the tenant registry when one is
persisted; otherwise it returns the canonical source registry. `registry_source`
distinguishes those cases. A corrupt persisted registry is refused. Discovery
does not grant invocation authority or certify provider availability.

App extensions retain their existing native user-consent gate. An agent binding
can stage a draft and cannot install or approve it through these HTTP methods.
IDE extension lifecycle state follows its native host process semantics.
Workbench layouts remain presentation state, independently of execution.
`examples/native-environment.ts` demonstrates the environment without a chat
turn. Other Theorem product APIs (such as Tasks and library management) are
separate surfaces and are not redirected through these resources.

Fern reports two native Space path-overlap warnings: `identity` is the reserved
static path for `client.spaces.identity()`, rather than an addressable Space ID.


## Regeneration

Pinned: Fern CLI 5.170.3 and TypeScript generator 3.107.3.

```sh
npm run check:api
npm run generate                # standard Fern workflow: Docker, Fern organization/auth
npm run generate:node           # Docker-free: Node, crane, tar, zip, unzip
npm run typecheck
npm test
npm run test:package            # build and verify an isolated installed tarball
```

The Node path uses Fern CLI to build the IR, downloads Fern's unmodified public
JavaScript generator layer using crane, verifies its pinned SHA-256, and invokes
its real entrypoint. It uses the same `generators.yml` configuration as the
standard workflow. The public artifact is pinned in `fern/generator-lock.json`;
cache and IR stay in gitignored `.fern/`. No custom HTTP client or SSE parser is
substituted. Explicit empty global headers prevent Fern from moving per-operation CSRF and
idempotency fields into global options as the catalog grows. The facade sets
`maxRetries: 0`, corrects cookie-auth options, and retains the first chat
slice's compatibility names; it introduces no transport or domain authority.

HTTP fixture tests exercise real fetch and streaming but do not prove a deployed
Rust backend. Live checks are gated and perform no fixture substitution:

```sh
# Export credentials from private secure configuration, then:
THEOREM_SDK_BASE_URL="$THEOREM_API_URL" THEOREM_SDK_TOKEN="$THEOREM_API_TOKEN" npm run test:live
# Optional: a real model turn in an idle disposable thread (leaves durable history).
THEOREM_SDK_BASE_URL="$THEOREM_API_URL" THEOREM_SDK_TOKEN="$THEOREM_API_TOKEN" \
THEOREM_SDK_THREAD_ID="$DISPOSABLE_THREAD_ID" THEOREM_SDK_LIVE_WRITE=1 npm run test:live
```

Sources: [Fern TypeScript SDK quickstart](https://buildwithfern.com/learn/sdks/generators/typescript/quickstart),
[Fern SSE metadata and resumption](https://buildwithfern.com/learn/sdks/deep-dives/sse-metadata),
and [assistant-ui custom runtime](https://www.assistant-ui.com/docs/runtimes/custom/local-runtime).
The Node generation path is implemented against the public Fern generator entrypoint;
configure your Fern organization in `fern/fern.config.json` before using the
standard authenticated workflow.


Native host acceptance (real HTTP, durable RedCore and process death), from the
repository root:

```sh
cargo test --locked --manifest-path apps/theorem-ide-host/Cargo.toml --test environment_http --test document_transactions
cargo build --locked --manifest-path apps/theorem-ide-host/Cargo.toml --bin theorem-ide-host
THEOREM_ENVIRONMENT_TEST_BINARY=/absolute/path/to/theorem-ide-host npm --prefix packages/theorem-sdk test
```

The SDK host test creates a private temporary credential and disposable state,
runs the actual host, commits a multi-document transaction, kills the host with
SIGKILL, and verifies both accepted revisions after a fresh process opens the
same authority. These checks do not deploy or claim a configured production host.

Native product-server acceptance adds the real serving tier. Prepare the pinned
extension runtime before running its positive formatting check:

```sh
npm install --prefix apps/vscode-bridge --ignore-scripts --no-audit --no-fund
bash apps/vscode-bridge/scripts/fetch-code-oss.sh
node apps/vscode-bridge/scripts/bundle-code-oss-exthost.mjs
node apps/vscode-bridge/scripts/generate-factory-vscode-module.mjs --check
cargo build --locked --manifest-path rustyredcore_THG/Cargo.toml -p rustyred-thg-server --bin rustyred-thg-server --example sdk_native_test_issuer
THEOREM_NATIVE_SERVER_TEST_BINARY=/absolute/path/to/rustyred-thg-server \
THEOREM_ENVIRONMENT_TEST_BINARY=/absolute/path/to/theorem-ide-host npm --prefix packages/theorem-sdk test
```

This test launches both shipping binaries with private temporary credentials and
durable stores. It checks product identity, CSRF and execution grants, capability
readback, app-extension drafting and user-consent refusal, IDE control, source
transactions, written-document transactions using actual Loro wire updates,
record patches, Space moves and workbench saves. It kills both native processes
and verifies acknowledged state from newly started processes. The Loro library
is a pinned test dependency; SDK runtime code remains framework independent.
The test also installs the hash-locked, unmodified Prettier VSIX and formats a
file through its actual native extension host. Its local credential helper calls
Theorem's canonical account issuer with an ephemeral key trusted only by the
disposable server, allowing successful app consent/install/update/uninstall
without relaxing the shipping admission gate. External identity-provider login
is not simulated or reported as verified.
CI builds both binaries and the test issuer and runs these checks. Missing binary paths produce an
explicit skip; hosted login/model checks remain separately credential gated.
