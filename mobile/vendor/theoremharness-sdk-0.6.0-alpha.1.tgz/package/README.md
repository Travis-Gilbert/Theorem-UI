# Theorem TypeScript SDK

SDK+ candidate `0.6.0-alpha.1`. The acceptance authority is current main with
native owners consolidated. Matched installed packages and the native server pass real model, ACP approval,
cancellation, shared Rust/TypeScript journal recovery, Files, configured Rusty
Red Web and read-only delegation checks locally. Complete capability accounting
and browser/all-family acceptance remain open. See the
[implementation record](../../docs/plans/sdk-foundation/IMPLEMENTATION.md) before
building a production consumer against this candidate.

Fern-generated native contracts for participating in Theorem's environment.
Chat is one supported slice, with an optional assistant-ui adapter. Runtime code uses native fetch and has no React dependency.
The package builds ESM, CommonJS, and TypeScript declarations for Node 20+ and
modern browsers. It has not been published to npm.

## Headless conversations

`HeadlessConversation` owns observation and durable pending command identity;
renderers subscribe to its state. It uses the generated client and requires no
React, DOM or GPUI runtime. For Node, use the atomic file store:

```ts
import { HeadlessConversation, TheoremClient } from '@theoremharness/sdk';
import { FileConversationStore } from '@theoremharness/sdk/headless-node';

const conversation = new HeadlessConversation({
  client: new TheoremClient({ baseUrl: authority, token }),
  authority, threadId,
  store: new FileConversationStore(journalDirectory),
});
await conversation.connect();
const unsubscribe = conversation.subscribe(render);
await conversation.send(commandId, { text: 'Hello', regime: 'solo' });
await conversation.observe();
unsubscribe();
conversation.detach();
```

The host supplies `authority`, credentials, an existing `threadId`, a stable
command ID, storage location and renderer. Browser hosts implement the exported
`ConversationStore` with durable atomic replacement. Keep one session writer per
journal; multiple views subscribe to that session. A replacement session reopens
the same journal and replays unresolved commands with their original identity.
Journals contain conversation data and pending effects, but never transport
credentials. A changed authenticated owner or a lossy thread revision is refused.

A pending send, edit or retry stays in the journal while its outcome is unknown
(a network failure, a 5xx, 408, 425, 429, or 401/403 until the person signs in
again) and is replayed with the same `Idempotency-Key`. When the owner answers
with any other client error (a stale `If-Match` is a 409) the answer is final:
the command is dropped from the journal, the call rejects with that error and
`state.error` carries it, and the conversation accepts a corrected request under
a new id. The Rust `Conversation` does the same (`Error::is_definite_refusal`).

`detach()` stops observation only. `stop(commandId)` durably requests cancellation,
including while admission is in flight. Await `observe()` before starting the next
turn: a terminal event can precede the final thread revision. Approvals remain in
`state.projection.approvals` across replacement; send an explicit `command()` using
the retained approval/run identity and the user's actual decision.

Send, edit and retry accept `webResearch: true` to request web research without
removing the turn's other admitted tools. It combines with `planning: true`.
An explicit `capabilityScope` remains a restriction and is never widened by
either request. Both assistant-ui adapters preserve these options.

High-level send/edit/retry accept `clientOperations` and `clientSurface`, using
the existing run owner's declarations. `Theorem.ClientOperationPart` and the
receipt types describe the corresponding request/answer. The command route also
accepts `WorkspaceReceipt`, derived from the workspace owner. Client operations
are limited to reading or presenting their declared page; they do not authorize
browser navigation or establish a visible host/tab binding.

## On `main`: contract ahead of the backend

`main` carries this v0.6 SDK (cherry-picked from `claude/platinum-master-lead`)
before the backend that serves it. v0.6 adds 82 operations to v0.4's 261 and
removes none. These are not yet served on `main` and fail there until the
backend lands: `/api/environment/v1/tools` (33), `/api/environment/v1/harness`
(18), `/api/files/v1/*` (~20), `/api/environment/v1/code-mode`, and
`/v1/sessions/{id}`. Every v0.4 operation behaves as before.

For the same reason, 8 native-owner conformance tests in `npm test` fail on
`main`, each because the backend file it checks against is not there yet:
policy schemas (13), catalog coverage debt (14), owner route bindings (18),
turn wire types (22), document summaries (23), document request contracts
(44), Files payload schemas (52), and Link policy records (79). They pass
once the backend is present; do not weaken them to turn `main` green.

## Build and install locally

```sh
cd packages/theorem-sdk
npm ci
npm run build
npm pack
```

Install the resulting tarball into your frontend. Import from
`@theoremharness/sdk`; the optional adapter is `@theoremharness/sdk/assistant-ui`.
The adapter types come from `@assistant-ui/core` (optional peer, `>=0.3.30 <0.4.0`),
which both `@assistant-ui/react` and `@assistant-ui/react-native` re-export, so web
and native bindings share one module. It is checked against
`@assistant-ui/react@0.15.30` and `@assistant-ui/react-native@0.1.51`.

## Native environment operations

The `files` group covers all 22 native vault operations under `/api/files/v1`.
Payloads derive from `theorem-surface-contracts::files_api`. Requests carry
`schema: "theorem-files/1"`; writes require CSRF and idempotency headers and can
carry preconditions and `X-Theorem-Client-Id`. `files.events` uses bounded long
polling. On a 412 refusal, `FilesProblem.currentHash: null` means the path is
absent. Documents, plans and AgentFS entries retain their native ownership and
read-only rules. Availability requires the Files backend as well as any web
proxy route.

`tools.list`, `tools.describe`, `tools.call`, `codeMode.exec`, `codeMode.wait`
and the named `harness` methods use native product HTTP routes over the shared
semantic owners. Inspect `isError` and the owner's receipt even after HTTP 200.
The HTTP idempotency header does not replace a tool's own retry identity;
code-mode execution carries that identity as `cellIdempotencyKey`. Discovery
provides dynamic tool schemas; these calls do not certify complete typed SDK
coverage. Admin tools require a separate exposure decision and are omitted.

Document create/revise/transaction inputs and their nested shapes come from
Schemars exports of the DTOs used by handlers. Regenerate those exports before
`npm run sync:contracts`, then regenerate both client projections. The Rust
distribution shares the exact contract bytes (`npm run check:rust-contract`).

The root client has independent `records`, `documents`, `spaces`, `workbench`,
`projectFiles`, `capabilities`, `extensions`, `remoteWorkspaces`, `documentSessions`
and `ide` resources. A record edit is a native form patch; a document
write is a revisioned document commit; a Space change saves presentation state.
None requires a chat message, tool-result card, or assistant-ui runtime.

```ts
const form = await client.records.get({ recordId: 'record-1' });
const result = await client.records.patch({
  recordIdPath: form.record_id,
  record_id: form.record_id,
  form_id: form.form_id,
  expected_revision: form.accepted_revision,
  request_id: operationKey,
  operations: [{ kind: 'set_value', field_id: titleFieldId,
    value: { kind: 'text', value: 'Edited directly' } }],
  'X-CSRF-Token': csrfToken,
  'Idempotency-Key': operationKey,
});
// A protocol conflict/refusal may be HTTP 200: inspect the native receipt.
if (result.receipt.outcome.kind === 'conflict') {
  console.log(result.receipt.outcome.actual_revision);
}
```

`examples/environment.ts` includes typed record edits, canonical document commits,
and independent Space presentation saves. Path/body identities use distinct SDK
names (`recordIdPath`, `documentIdPath`, `workspaceIdPath`) where the native wire
requires both copies. The generated client preserves both instead of dropping a
body field while constructing a URL.

Each owner keeps its revision and refusal vocabulary. Record revisions are
strings carried by `expected_revision`; document revisions include a position
and digest; Space and workbench writes use their own revision and `If-Match`.
Document errors are typed under `Theorem.documents`, record transport errors
under `Theorem.records`, and record protocol outcomes stay in their receipts.

Use `client.environment.bootstrap()` for authenticated environment identity and
shared CSRF protection. It creates no chat state. The original
`session.bootstrap()` remains available for chat integrations. Resource methods
do not bootstrap implicitly.

## Client

```ts
import { TheoremClient, Theorem } from '@theoremharness/sdk';

// Server-side: use an existing Theorem credential with tenant:read/tenant:write
// and models:invoke when starting turns. Tenant is derived by the server.
const client = new TheoremClient({
  baseUrl: process.env.THEOREM_API_URL!,
  token: () => process.env.THEOREM_API_TOKEN!,
});

const session = await client.session.bootstrap();
const project = await client.chat.projects.create({
  title: 'Research',
  'X-CSRF-Token': session.csrfToken,
  'Idempotency-Key': crypto.randomUUID(),
});
const thread = await client.chat.threads.create({
  projectId: project.record.projectId,
  'X-CSRF-Token': session.csrfToken,
  'Idempotency-Key': crypto.randomUUID(),
});
const turn = await client.chat.messages.send({
  threadId: thread.record.threadId,
  branchId: thread.record.selectedBranchId,
  text: 'Hello, Theorem',
  'X-CSRF-Token': session.csrfToken,
  'Idempotency-Key': crypto.randomUUID(),
  'If-Match': String(thread.record.revision),
});
for await (const event of await client.chat.runs.events({ runId: turn.run.runId, after_seq: 0 })) {
  console.log(event.sourceEventType, event.payload);
}
```

In a browser with an existing Theorem session, use
`new TheoremClient({ baseUrl: window.location.origin, auth: false })`. Requests
include cookies. Use a same-origin reverse proxy for a separately hosted frontend;
this SDK does not establish login or configure backend CORS. Never embed a server
API token in frontend code. `baseUrl` may include an owner/path prefix.

Mutation headers are explicit. Keep an operation's idempotency key and original
request unchanged for a retry. Implicit retries default to zero: terminals, SCM,
workers and extension actions retain their native effect and retry semantics.
Override `maxRetries` only for an operation whose owner permits repetition. Revisioned mutations require `If-Match`; refresh the thread before
a new operation. Typed problems include `code`, `correlationId`, `receiptId`, and
`currentRevision` where the server provides them. For example:

```ts
try { /* a revisioned mutation */ }
catch (error) {
  if (error instanceof Theorem.ConflictError) console.log(error.body.code);
  else throw error;
}
```

## assistant-ui

```tsx
import { useMemo } from 'react';
import { AssistantRuntimeProvider, useLocalRuntime } from '@assistant-ui/react';
import { createTheoremChatAdapter, toAssistantMessages } from '@theoremharness/sdk/assistant-ui';

// Load before mounting: snapshot = await client.chat.threads.get({ threadId }).
function Chat({ client, threadId, snapshot, children }) {
  const adapter = useMemo(() => createTheoremChatAdapter({ client, threadId }), [client, threadId]);
  const runtime = useLocalRuntime(adapter, { initialMessages: toAssistantMessages(snapshot.messages, snapshot.thread) });
  return <AssistantRuntimeProvider runtime={runtime}>{children}</AssistantRuntimeProvider>;
}
```

A fully typed provider/loader example is in `examples/assistant-ui.tsx`. Mount your
assistant-ui Thread inside the provider and use `key={threadId}` when switching
threads. The adapter sends the latest user turn; Theorem owns the full history.
Regeneration of known durable user IDs calls retry; edits retaining those IDs
call edit. Custom editing UIs that replace user IDs should invoke
`client.chat.messages.edit` and reload the returned branch. Initial history preserves
server IDs for regeneration after reload.

Cumulative text/reasoning parts replace their earlier version. Tool calls/results
merge by toolCallId; native parts use assistant-ui data parts named
`theorem-<type>`. `onEvent` exposes all native events. Tools execute on the server;
do not register client executors for the same tools. Approval requests remain
native events/data; send decisions through `client.chat.runs.command` and provide
appropriate UI. A `tool_approval` part lands on its tool call: its latest
snapshot is the part's `artifact.theoremApproval`, settled or not, and the
part carries a human `interrupt` only while that approval awaits a decision
(`requires_action`, `pending`, `open`, or no status yet). An approval that was
answered, expired or replaced therefore does not leave the message requiring
action. The adapter does not install an approval UI or attachment uploader.
For already uploaded files, use `client.chat.messages.send({ ..., uploadIds })`.

### External-store binding (shared by web and native)

`projectThreadView(state)` is a pure projection of `HeadlessConversation` state
for assistant-ui's external-store runtime. It renders the snapshot's durable
messages, replaces the live run's persisted copy with its cumulative parts until
the run is terminal and persisted (so a resumed run renders without a new send),
and shows journal sends as optimistic user messages until they are acknowledged.
It never dispatches anything: disposing a view only unsubscribes, and a stop is
an explicit `session.stop` from the runtime's `onCancel`. The iOS app in
Theorem-UI (`mobile/`) binds it with `useExternalStoreRuntime`:

```tsx
const [state, setState] = useState(() => session.state);
useEffect(() => session.subscribe(setState), [session]); // detach ≠ stop
const view = projectThreadView(state);
const runtime = useExternalStoreRuntime({
  messages: view.messages, isRunning: view.isRunning, convertMessage: (m) => m,
  onNew: async (m) => { await session.send(crypto.randomUUID(), { text: textOf(m) }); },
  onCancel: () => session.stop(crypto.randomUUID()),
});
```

Stop aborts the stream and records a separate durable run cancellation. A stop
pressed during submission waits for its run handle, then cancels it at once,
without waiting for the thread refresh that follows. Server
cancellation is cooperative. Cancellation failures propagate. Failed runs,
interrupted outcomes, and streams ending without a terminal event are not marked
successful. Existing active/pending turns require explicit recovery before a new
adapter run.

## Streaming and recovery

`client.chat.runs.events` returns a Fern AsyncIterable. `stream.withMetadata()` adds
SSE IDs. Resume with `after_seq: lastEvent.seq` or `'Last-Event-ID': savedId`
(the header takes precedence). The server emits no special SSE terminator, so
this SDK deliberately does not enable Fern's terminator-dependent automatic
reconnection. If a connection drops, resume the same run; do not send the user
message again. The assistant-ui adapter surfaces interrupted streams so the host
can present recovery. When reading from sequence zero, replace parts by partId.

## Supported contracts

| Resource | Methods |
| --- | --- |
| environment | bootstrap (product identity and shared CSRF) |
| capabilities | list and describe canonical descriptors, policy, maturity and proof |
| remoteWorkspaces | list, open, describe, close, restart, attach, detach, listWorkers, startWorker, crashWorker, bindCheckout, attachDebug |
| documentSessions | native source-document open, edit, transaction, undoTransaction, head, history, reconciliation and replication |
| extensions | native IDE extension discover/install/enable/disable/update/pin/activate/restartHost |
| extensions.apps | app manifests, extension points/contributions, drafts, install/update/uninstall, consent/deny/refresh |
| ide | operation discovery and native workspace, workbench, language, navigation, diagnostics, refactor, terminal, SCM, run, test, debug, history and custom-editor services |
| session | original chat bootstrap |
| records | list, get, surface, create, patch, history |
| documents | list, get, snapshot, create, revise, transact, promote, changes |
| spaces | identity, list, get, save |
| workbench | get, save (presentation state) |
| projectFiles | root, children, content (bound checkout reads) |
| chat.projects | list, create, update |
| chat.threads | list, create, get, update, delete, restore, fork |
| chat.messages | send, edit, retry |
| chat.runs | events, cancel, command |
| acp | agents, list, start, close |

The contract is `fern/openapi.json`, titled **Theorem Environment API**, with 255
operations. Every operation names its native source owner in `x-theorem-source`.
`generated/` is actual Fern output; `generated/reference.md` lists signatures.
The first chat package's root project/thread/message/run getters and request type
aliases remain for compatibility; use `client.chat` for new integrations.

The 184 IDE service operations are derived from the owner's actual advertised
registry by `scripts/update-environment-contract.mjs`. Formal native records
have typed request/response models. Services whose native contract is
`serde_json::Value` retain JSON arguments and return their exact JSON value;
the SDK does not invent a replacement protocol. Native subscription operations
retain the host's current acknowledgement/polling semantics. Chat has its own
SSE stream.

Remote execution uses the existing `theorem-ide-host` supervisor with an
fsynced RedCore source-document authority. The product server authenticates the
user, derives tenant/actor, checks an explicit principal execution grant, then
forwards to that tenant's configured native host. Missing host configuration
fails closed. See [host configuration](../../apps/theorem-ide-host/README.md).
The SDK opens workspaces on a configured host; deployment infrastructure
provisions that host. Host credentials never belong in frontend code.

`client.documentSessions.transaction()` commits native multi-file source edits
atomically; `preview: true` returns the native preview. By contrast,
`client.documents.transact()` imports a batch of base64 Loro wire updates into a
staged written-document session, then commits one revision through the document
product authority. It validates the native position/digest precondition and
idempotency key. Invalid or dependency-incomplete batches publish nothing.
Use the Loro library to create updates; the SDK contains no CRDT encoder.

Capability discovery verifies and returns the tenant registry when one is
persisted; otherwise it returns the canonical source registry. `registry_source`
distinguishes those cases. A corrupt persisted registry is refused. Discovery
does not grant invocation authority or certify provider availability.

App extensions retain their existing native user-consent gate. An agent binding
can stage a draft and cannot install or approve it through these HTTP methods.
IDE extension lifecycle state follows its native host process semantics.
Workbench layouts remain presentation state, independently of execution.
`examples/native-environment.ts` demonstrates the environment without a chat
turn. Other Theorem product APIs (such as Tasks and library management) are
separate surfaces and are not redirected through these resources.

Fern reports two native Space path-overlap warnings: `identity` is the reserved
static path for `client.spaces.identity()`, rather than an addressable Space ID.


## Regeneration

Pinned: Fern CLI 5.170.3 and TypeScript generator 3.107.3.

```sh
npm run check:api
npm run generate                # standard Fern workflow: Docker, Fern organization/auth
npm run generate:node           # Docker-free: Node, crane, tar, zip, unzip
npm run typecheck
npm test
npm run test:package            # build and verify an isolated installed tarball
```

The Node path uses Fern CLI to build the IR, downloads Fern's unmodified public
JavaScript generator layer using crane, verifies its pinned SHA-256, and invokes
its real entrypoint. It uses the same `generators.yml` configuration as the
standard workflow. The public artifact is pinned in `fern/generator-lock.json`;
cache and IR stay in gitignored `.fern/`. No custom HTTP client or SSE parser is
substituted. Explicit empty global headers prevent Fern from moving per-operation CSRF and
idempotency fields into global options as the catalog grows. The facade sets
`maxRetries: 0`, corrects cookie-auth options, and retains the first chat
slice's compatibility names; it introduces no transport or domain authority.

HTTP fixture tests exercise real fetch and streaming but do not prove a deployed
Rust backend. Live checks are gated and perform no fixture substitution:

```sh
# Export credentials from private secure configuration, then:
THEOREM_SDK_BASE_URL="$THEOREM_API_URL" THEOREM_SDK_TOKEN="$THEOREM_API_TOKEN" npm run test:live
# Optional: a real model turn in an idle disposable thread (leaves durable history).
THEOREM_SDK_BASE_URL="$THEOREM_API_URL" THEOREM_SDK_TOKEN="$THEOREM_API_TOKEN" \
THEOREM_SDK_THREAD_ID="$DISPOSABLE_THREAD_ID" THEOREM_SDK_LIVE_WRITE=1 npm run test:live
```

Sources: [Fern TypeScript SDK quickstart](https://buildwithfern.com/learn/sdks/generators/typescript/quickstart),
[Fern SSE metadata and resumption](https://buildwithfern.com/learn/sdks/deep-dives/sse-metadata),
and [assistant-ui custom runtime](https://www.assistant-ui.com/docs/runtimes/custom/local-runtime).
The Node generation path is implemented against the public Fern generator entrypoint;
configure your Fern organization in `fern/fern.config.json` before using the
standard authenticated workflow.


Native host acceptance (real HTTP, durable RedCore and process death), from the
repository root:

```sh
cargo test --locked --manifest-path apps/theorem-ide-host/Cargo.toml --test environment_http --test document_transactions
cargo build --locked --manifest-path apps/theorem-ide-host/Cargo.toml --bin theorem-ide-host
THEOREM_ENVIRONMENT_TEST_BINARY=/absolute/path/to/theorem-ide-host npm --prefix packages/theorem-sdk test
```

The SDK host test creates a private temporary credential and disposable state,
runs the actual host, commits a multi-document transaction, kills the host with
SIGKILL, and verifies both accepted revisions after a fresh process opens the
same authority. These checks do not deploy or claim a configured production host.

Native product-server acceptance adds the real serving tier. Prepare the pinned
extension runtime before running its positive formatting check:

```sh
npm install --prefix apps/vscode-bridge --ignore-scripts --no-audit --no-fund
bash apps/vscode-bridge/scripts/fetch-code-oss.sh
node apps/vscode-bridge/scripts/bundle-code-oss-exthost.mjs
node apps/vscode-bridge/scripts/generate-factory-vscode-module.mjs --check
cargo build --locked --manifest-path rustyredcore_THG/Cargo.toml -p rustyred-thg-server --bin rustyred-thg-server --example sdk_native_test_issuer
THEOREM_NATIVE_SERVER_TEST_BINARY=/absolute/path/to/rustyred-thg-server \
THEOREM_ENVIRONMENT_TEST_BINARY=/absolute/path/to/theorem-ide-host npm --prefix packages/theorem-sdk test
```

This test launches both shipping binaries with private temporary credentials and
durable stores. It checks product identity, CSRF and execution grants, capability
readback, app-extension drafting and user-consent refusal, IDE control, source
transactions, written-document transactions using actual Loro wire updates,
record patches, Space moves and workbench saves. It kills both native processes
and verifies acknowledged state from newly started processes. The Loro library
is a pinned test dependency; SDK runtime code remains framework independent.
The test also installs the hash-locked, unmodified Prettier VSIX and formats a
file through its actual native extension host. Its local credential helper calls
Theorem's canonical account issuer with an ephemeral key trusted only by the
disposable server, allowing successful app consent/install/update/uninstall
without relaxing the shipping admission gate. External identity-provider login
is not simulated or reported as verified.
CI builds both binaries and the test issuer and runs these checks. Missing binary paths produce an
explicit skip; hosted login/model checks remain separately credential gated.
# Lossless integers

Native Rust `u64` revisions can exceed JavaScript's safe integer range. The SDK
returns safe values as `number` and larger integers as `bigint`; generated
unsigned 64-bit fields expose `number | bigint`. Keep those values intact when
echoing a revision or cursor. Use the exported `parseJson`/`stringifyJson` for
application storage of SDK values; `JSON.stringify` cannot encode a bigint.
The SDK's durable Node journal already uses that encoding, compatible with Rust.
Unsafe integer-valued JavaScript numbers are refused on serialization: use bigint
before the value is rounded.

The generation pipeline installs an explicit bridge from Fern's JSON runtime to
the pinned `lossless-json` dependency. Fern still owns HTTP, retries and SSE.
This avoids the pinned generator's BigInt marker collision with ordinary strings.
Both generation commands install the same bridge; generated files are not edited
by hand. Owner schema exports retain `uint64` for Rust and annotate Fern's `long`
representation, because its uint64 generator otherwise emits plain number.

Link suggestion thresholds use their own signed native owner:
`client.linkPolicy.get()` and `client.linkPolicy.update(...)`. Updates require
`X-CSRF-Token`, `Idempotency-Key`, `thresholds` and an optional
`expected_revision` (null for an initial policy). The generated wire fields
remain snake_case. Existing revisions use compare-and-swap; a stale update
returns the native Link admission refusal. Reusing a successful idempotency key
replays its result. TypeScript preserves large uint64 revisions as bigint.

Headless recovery keeps `chat_run_start_pending` responses in the durable journal,
including HTTP 409: the message already exists, so reconnect replays its original
idempotency key and revision to start the answer. Ordinary revision conflicts
remain definite refusals and permit a corrected send under a new key. Unreadable
error responses remain pending until the owner can establish the outcome.

## Executable plans and Claude Mods

The `@theoremharness/sdk/claude` entry uses Claude host HTTP and clock APIs,
including the same lossless integer codec as other SDK transports. The mod
registers individually typed native tools; it does not require an MCP server.
`consumeEventBatch` accepts a `fetchChunk` callback and optional `maxBytes` for
bounded spill hydration before application and acknowledgment.
See [the mod guide](mods/claude/README.md) and the [implementation record](../../docs/plans/claude-mod-sdk-20261030/README.md) for native requirements, current evidence and unfinished integration.
